package br.com.dh.dentistas3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dentistas3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
